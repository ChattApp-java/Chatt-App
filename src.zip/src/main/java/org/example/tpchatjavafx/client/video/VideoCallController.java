package org.example.tpchatjavafx.client.video;

import com.github.sarxos.webcam.Webcam;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import org.example.tpchatjavafx.client.NetworkClient;
import org.example.tpchatjavafx.client.audio.AudioCaptureService;
import org.example.tpchatjavafx.client.audio.AudioFormatUtil;
import org.example.tpchatjavafx.client.model.ChatMessage;
import org.example.tpchatjavafx.common.MessageType;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Timer;
import java.util.TimerTask;

public class VideoCallController {

    @FXML private ImageView localVideo;
    @FXML private ImageView remoteVideo;
    @FXML private Label remoteNameLabel;
    @FXML private Label remoteNameOverlayLabel;
    @FXML private Label statusLabel;
    @FXML private Label timerLabel;
    @FXML private Label callTypeLabel;
    @FXML private Button videoButton;
    @FXML private Button speakerButton;
    @FXML private Button micButton;
    @FXML private Button endCallButton;
    @FXML private VBox remotePlaceholder;
    @FXML private VBox localPlaceholder;

    private static VideoCallController instance;

    private NetworkClient networkClient;
    private String username;
    private String otherUser;
    private Timer cameraTimer;
    private Webcam webcam;

    private TargetDataLine mic;
    private SourceDataLine speakers;
    private volatile boolean audioRunning;
    private Thread audioCaptureThread;
    private AudioFormat captureFormat;
    private AudioFormat playbackFormat;

    private Timeline timerTimeline;
    private int elapsedSeconds;
    private volatile boolean microphoneMuted;
    private volatile boolean speakerEnabled = true;
    private volatile boolean videoEnabled = true;

    public void init(NetworkClient client, String me, String other) {
        instance = this;
        this.networkClient = client;
        this.username = me;
        this.otherUser = other;
        this.microphoneMuted = false;
        this.speakerEnabled = true;
        this.videoEnabled = true;

        remoteNameLabel.setText(other != null && !other.isBlank() ? other : "Contact");
        if (remoteNameOverlayLabel != null) {
            remoteNameOverlayLabel.setText(other != null && !other.isBlank() ? other : "Contact");
        }
        callTypeLabel.setText("Appel video");
        statusLabel.setText("Connexion video active");
        remotePlaceholder.setVisible(true);
        remotePlaceholder.setManaged(true);
        localPlaceholder.setVisible(false);
        localPlaceholder.setManaged(false);
        localVideo.setImage(null);
        remoteVideo.setImage(null);
        updateMicButton();
        updateSpeakerButton();
        updateVideoButton();
        startTimer();

        webcam = Webcam.getDefault();
        if (webcam != null) {
            webcam.open();
        } else {
            videoEnabled = false;
            localPlaceholder.setVisible(true);
            localPlaceholder.setManaged(true);
            statusLabel.setText("Aucune camera detectee");
        }

        startSendingCameraFrames();

        try {
            startAudio();
        } catch (LineUnavailableException e) {
            statusLabel.setText("Audio indisponible sur ce PC");
            System.err.println("Impossible de demarrer l'audio : " + e.getMessage());
        }
    }

    private void startSendingCameraFrames() {
        cameraTimer = new Timer(true);
        cameraTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (!videoEnabled || webcam == null || !webcam.isOpen()) {
                    return;
                }

                try {
                    BufferedImage img = webcam.getImage();
                    if (img == null) {
                        return;
                    }

                    Image fxImage = javafx.embed.swing.SwingFXUtils.toFXImage(img, null);
                    Platform.runLater(() -> {
                        localPlaceholder.setVisible(false);
                        localPlaceholder.setManaged(false);
                        localVideo.setImage(fxImage);
                    });

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    ImageIO.write(img, "jpg", baos);
                    byte[] data = baos.toByteArray();

                    ChatMessage msg = new ChatMessage(
                            MessageType.VIDEO_FRAME,
                            username,
                            otherUser,
                            null,
                            null
                    );
                    msg.setBinaryData(data);
                    networkClient.send(msg);
                } catch (Exception ignored) {
                }
            }
        }, 0, 100);
    }

    public static void receiveFrame(byte[] data) {
        if (instance == null || data == null) {
            return;
        }

        try {
            Image fxImage = new Image(new ByteArrayInputStream(data));
            Platform.runLater(() -> {
                if (instance == null) {
                    return;
                }
                instance.remoteVideo.setImage(fxImage);
                instance.remotePlaceholder.setVisible(false);
                instance.remotePlaceholder.setManaged(false);
                if (!instance.videoEnabled) {
                    instance.statusLabel.setText("Camera locale coupee, video distante visible");
                } else {
                    instance.statusLabel.setText("Video en direct");
                }
            });
        } catch (Exception ignored) {
        }
    }

    private void startAudio() throws LineUnavailableException {
        AudioFormat format = AudioCaptureService.findBestDuplexFormat();
        if (format == null) {
            format = new AudioFormat(44100, 16, 1, true, false);
        }

        DataLine.Info micInfo = new DataLine.Info(TargetDataLine.class, format);
        DataLine.Info spkInfo = new DataLine.Info(SourceDataLine.class, format);

        mic = (TargetDataLine) AudioSystem.getLine(micInfo);
        mic.open(format);
        mic.start();
        captureFormat = format;

        speakers = (SourceDataLine) AudioSystem.getLine(spkInfo);
        speakers.open(format);
        speakers.start();
        playbackFormat = format;

        audioRunning = true;
        audioCaptureThread = new Thread(this::audioCaptureLoop, "video-audio-capture");
        audioCaptureThread.setDaemon(true);
        audioCaptureThread.start();
    }

    private void audioCaptureLoop() {
        byte[] buffer = new byte[2048];
        try {
            while (audioRunning) {
                int count = mic.read(buffer, 0, buffer.length);
                if (count <= 0 || microphoneMuted) {
                    continue;
                }

                byte[] frame = new byte[count];
                System.arraycopy(buffer, 0, frame, 0, count);
                if (!AudioFormatUtil.sameFormat(captureFormat, AudioFormatUtil.NETWORK_FORMAT)) {
                    frame = AudioFormatUtil.convert(frame, captureFormat, AudioFormatUtil.NETWORK_FORMAT);
                }

                ChatMessage msg = new ChatMessage(MessageType.VOICE_FRAME, username, otherUser, null, "vframe");
                msg.setBinaryData(frame);
                networkClient.send(msg);
            }
        } catch (Exception ignored) {
        }
    }

    public static void receiveAudio(byte[] data) {
        if (instance == null || instance.speakers == null || !instance.audioRunning || data == null) {
            return;
        }
        if (!instance.speakerEnabled) {
            return;
        }

        if (!AudioFormatUtil.sameFormat(AudioFormatUtil.NETWORK_FORMAT, instance.playbackFormat)) {
            data = AudioFormatUtil.convert(data, AudioFormatUtil.NETWORK_FORMAT, instance.playbackFormat);
        }
        instance.speakers.write(data, 0, data.length);
    }

    @FXML
    public void onToggleMic() {
        microphoneMuted = !microphoneMuted;
        updateMicButton();
        refreshStatusText();
    }

    @FXML
    public void onToggleSpeaker() {
        speakerEnabled = !speakerEnabled;
        updateSpeakerButton();
        refreshStatusText();
    }

    @FXML
    public void onToggleVideo() {
        videoEnabled = !videoEnabled;
        if (!videoEnabled) {
            localVideo.setImage(null);
            localPlaceholder.setVisible(true);
            localPlaceholder.setManaged(true);
        } else if (webcam == null) {
            statusLabel.setText("Aucune camera detectee");
        }
        updateVideoButton();
        refreshStatusText();
    }

    @FXML
    public void onEndCall() {
        cleanupMedia();

        if (networkClient != null) {
            networkClient.send(new ChatMessage(
                    MessageType.VIDEO_CALL_END,
                    username,
                    otherUser,
                    null,
                    ""
            ));
        }

        VideoCallWindow.closeCurrent();
    }

    private void cleanupMedia() {
        if (cameraTimer != null) {
            cameraTimer.cancel();
            cameraTimer = null;
        }

        if (webcam != null && webcam.isOpen()) {
            webcam.close();
        }
        webcam = null;

        audioRunning = false;
        if (audioCaptureThread != null) {
            try {
                audioCaptureThread.join(300);
            } catch (InterruptedException ignored) {
            }
            audioCaptureThread = null;
        }

        if (mic != null) {
            mic.stop();
            mic.close();
            mic = null;
        }

        if (speakers != null) {
            speakers.stop();
            speakers.close();
            speakers = null;
        }

        if (timerTimeline != null) {
            timerTimeline.stop();
            timerTimeline = null;
        }

        instance = null;
    }

    private void startTimer() {
        elapsedSeconds = 0;
        timerLabel.setText("00:00");
        if (timerTimeline != null) {
            timerTimeline.stop();
        }

        timerTimeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            elapsedSeconds++;
            int minutes = elapsedSeconds / 60;
            int seconds = elapsedSeconds % 60;
            timerLabel.setText(String.format("%02d:%02d", minutes, seconds));
        }));
        timerTimeline.setCycleCount(Timeline.INDEFINITE);
        timerTimeline.play();
    }

    private void refreshStatusText() {
        if (!videoEnabled && microphoneMuted && !speakerEnabled) {
            statusLabel.setText("Camera, micro et haut-parleur coupes");
        } else if (!videoEnabled && microphoneMuted) {
            statusLabel.setText("Camera et micro coupes");
        } else if (!videoEnabled && !speakerEnabled) {
            statusLabel.setText("Camera et haut-parleur coupes");
        } else if (microphoneMuted && !speakerEnabled) {
            statusLabel.setText("Micro et haut-parleur coupes");
        } else if (!videoEnabled) {
            statusLabel.setText("Camera locale coupee");
        } else if (microphoneMuted) {
            statusLabel.setText("Micro coupe");
        } else if (!speakerEnabled) {
            statusLabel.setText("Haut-parleur coupe");
        } else if (remoteVideo.getImage() != null) {
            statusLabel.setText("Video en direct");
        } else {
            statusLabel.setText("Connexion video active");
        }
    }

    private void updateMicButton() {
        micButton.setText(microphoneMuted ? "Mic off" : "Mic");
        micButton.setStyle(
                "-fx-background-color: " + (microphoneMuted ? "#f15c6d" : "#233138") + ";" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 12px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-min-width: 58px;" +
                        "-fx-min-height: 58px;" +
                        "-fx-max-width: 58px;" +
                        "-fx-max-height: 58px;" +
                        "-fx-background-radius: 29;"
        );
    }

    private void updateSpeakerButton() {
        speakerButton.setText(speakerEnabled ? "HP" : "HP off");
        speakerButton.setStyle(
                "-fx-background-color: " + (speakerEnabled ? "#233138" : "#f15c6d") + ";" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 12px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-min-width: 58px;" +
                        "-fx-min-height: 58px;" +
                        "-fx-max-width: 58px;" +
                        "-fx-max-height: 58px;" +
                        "-fx-background-radius: 29;"
        );
    }

    private void updateVideoButton() {
        videoButton.setText(videoEnabled ? "Cam" : "Cam off");
        videoButton.setStyle(
                "-fx-background-color: " + (videoEnabled ? "#233138" : "#f15c6d") + ";" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 12px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-min-width: 58px;" +
                        "-fx-min-height: 58px;" +
                        "-fx-max-width: 58px;" +
                        "-fx-max-height: 58px;" +
                        "-fx-background-radius: 29;"
        );
        endCallButton.setStyle(
                "-fx-background-color: #f15c6d;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 12px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-min-width: 58px;" +
                        "-fx-min-height: 58px;" +
                        "-fx-max-width: 58px;" +
                        "-fx-max-height: 58px;" +
                        "-fx-background-radius: 29;"
        );
    }
}
